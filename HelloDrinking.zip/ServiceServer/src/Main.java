import kr.android.hellodrinking.server.HelloDrinkingServer;

public class Main {
	public static void main(String[] args) throws Exception {
		HelloDrinkingServer server = new HelloDrinkingServer();
		server.start();
	}
}


public class MainServer {
	public static void main(String[] args) throws Exception {
		StartServer server = new StartServer();
		server.start();
	}
}

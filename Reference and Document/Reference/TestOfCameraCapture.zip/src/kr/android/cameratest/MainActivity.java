package kr.android.cameratest;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class MainActivity extends Activity implements OnClickListener {
	private Button mButtonCameraCapture, mButtonCameraMode;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		
		mButtonCameraCapture = (Button) findViewById(R.id.main_button_cameracapture);
		mButtonCameraMode = (Button) findViewById(R.id.main_button_cameramode);
		
		mButtonCameraCapture.setOnClickListener(this);
		mButtonCameraMode.setOnClickListener(this);
	}

	@Override
	public void onClick(View view) {
		if(view.getId() == R.id.main_button_cameracapture){
			Intent intent = new Intent(this, CameraCaptureActivity.class);
			startActivity(intent);
		}else if(view.getId() == R.id.main_button_cameramode){
			Intent intent = new Intent(this, CameraModeActivity.class);
			startActivity(intent);			
		}
	}
}

package kr.android.cameratest;

import android.app.Activity;
import android.os.Bundle;
import android.view.Window;

/*
 * 참조 : http://hyena0.tistory.com/355
 */

public class CameraModeActivity extends Activity {
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.cameramode);
	}
}
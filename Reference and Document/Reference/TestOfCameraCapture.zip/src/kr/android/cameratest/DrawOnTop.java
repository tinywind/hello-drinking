package kr.android.cameratest;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

public class DrawOnTop extends View {
	public DrawOnTop(Context context) {
		super(context);
	}
	
	public DrawOnTop(Context context, AttributeSet attributes){
		super(context, attributes);
	}
	
	@Override
	protected void onDraw(Canvas canvas) {
		Paint paint = new Paint();
		paint.setStyle(Paint.Style.FILL);
		paint.setColor(Color.RED); // 적색
		paint.setStrokeWidth(10); // 크기 10
		canvas.drawText("Test Text", 10, 10, paint); // 텍스트 표시
		canvas.drawLine(50, 50, 200, 200, paint); // 라인그리기
		super.onDraw(canvas);
	}
}
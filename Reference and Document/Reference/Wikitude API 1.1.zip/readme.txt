The Wikitude API 1.1.0 release contains the following files:

- wikitudearintent.jar (The jar distribution of the API)
- Wikitude_AR_API_javadocs.zip (the javadocs of the API classes)
- Wikitude_API_1.1_Documentation.pdf (a documentation of the API)
- BasicOpenARDemo.zip (a sample app which makes use of the Wikitude API)
- wtc_old_triang.obj (The sample model file which should be copied onto the sdcard when running the sample app in 3D mode
- readme.txt (this file)
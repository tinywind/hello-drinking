package etc;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import midi.MidiItem;


import composition.Measure;

public class MidiModel {
	private MidiItem _model;
	private List<MidiModelListener> _listeners;

	public MidiModel(MidiItem item){
		_model = item;
		_listeners = new ArrayList<MidiModelListener>();
	}

	public int getMeasureSize(){
		return _model.getMeasures().size();
	}
	
	public void setModel(MidiItem item){
		_model = item;
		notifyAllChanged();
	}

	private void notifyAllChanged() {
		Iterator<MidiModelListener> it = _listeners.iterator();
		while(it.hasNext()){
			it.next().midiChanged(new ValueChangeEvent(this));
		}
	}

	public void addMeasure(Measure measure){
		_model.addMeasure(measure);
		notifyMeasureAdded();
	}
	
	private void notifyMeasureAdded() {
		Iterator<MidiModelListener> it = _listeners.iterator();
		while(it.hasNext()){
			it.next().measureAdded(new ValueChangeEvent(this));
		}	
	}

	public boolean changeMeasure(Measure destination, Measure source){
		int index = _model.changeMeasure(destination, source); 
		if(index > 0){
			notifyMeasureChanged(index);
			return true;
		}else
			return false;
	}

	private void notifyMeasureChanged(int index) {
		Iterator<MidiModelListener> it = _listeners.iterator();
		while(it.hasNext()){
			it.next().measureChanged(new ValueChangeEvent(this, index));
		}		
	}

	public boolean removeMeasure(Measure destination){
		int index = _model.removeMeasure(destination);
		if(index<0)
			return false;
		
		notifyMeasureRemoved(index);
		return true;
	}

	private void notifyMeasureRemoved(int index) {
		Iterator<MidiModelListener> it = _listeners.iterator();
		while(it.hasNext()){
			it.next().measureRemoved(new ValueChangeEvent(this,index));
		}			
	}

	public MidiItem getMidiItem() {
		return _model;
	}

	public void addListener(MidiModelListener listener) {
		_listeners.add(listener);
	}

	public void play() {


		
//		MidiItem midiItem = new MidiItem();
//		midiItem.setMetaInfo(metaInfo);
//
//		Iterator<Measure> it = measures.iterator();
//		while(it.hasNext()){
//			Iterator<Note> it2 = (it.next()).iterator();
//			while(it2.hasNext()){
//				midiItem.add(it2.next());
//			}
//		}
//		midiplayer = new MidiPlayer(midiItem);
//		midiplayer.start();
	}
}

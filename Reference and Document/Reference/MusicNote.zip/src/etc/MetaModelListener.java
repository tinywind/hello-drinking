package etc;

public interface MetaModelListener {	
	public void modelChanged(ValueChangeEvent e);
	public void titleChanged(ValueChangeEvent e);
	public void authorChanged(ValueChangeEvent e);
	public void tempoChanged(ValueChangeEvent e);
	public void commentChanged(ValueChangeEvent e);
	public void copyrightChanged(ValueChangeEvent e);
	public void dateChanged(ValueChangeEvent e);
	public void keyChanged(ValueChangeEvent e);
}

package etc;

public interface MidiModelListener {
	public void midiChanged(ValueChangeEvent e);	
	public void measureChanged(ValueChangeEvent e);
	public void measureRemoved(ValueChangeEvent e);
	public void measureAdded(ValueChangeEvent e);
	
}

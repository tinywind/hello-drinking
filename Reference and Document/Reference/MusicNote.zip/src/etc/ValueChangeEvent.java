package etc;

public class ValueChangeEvent {
	private int _state;

	public ValueChangeEvent(Object source){
		_source = source;
		_state = 0;
	}
	public ValueChangeEvent(Object source, int state){
		_source = source;
		_state = state;
	}
	
	public void setState(int state){
		_state = state;
	}
	
	public int getState(){
		return _state;
	}
	
	public Object getSource(){
		return _source;
	}
	
	private Object _source;
}

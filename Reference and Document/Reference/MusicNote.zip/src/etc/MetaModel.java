package etc;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import midi.MetaInformation;
import midi.MidiItem;


import composition.Key;

public class MetaModel {	
	private List<MetaModelListener> _listeners;
	private MidiItem _midiItem;
	private MetaInformation _model;	
	
	public MetaModel(MidiModel model){
		_listeners = new ArrayList<MetaModelListener>();
		_midiItem = model.getMidiItem();
		_model = _midiItem.getMetaInfo();
	}
	
	public MetaModel(MidiItem item){
		_listeners = new ArrayList<MetaModelListener>();
		_midiItem = item;
		_model = _midiItem.getMetaInfo();
	}
	
	public void setModel(MetaInformation meta){
		_model = meta;
		notifyAllToListeners();
	}
	
	public MetaInformation getMeta(){
		return _model;
	}
	
	public void setTitle(String title){
		_model.setTitle(title);
		notifyTitleChanged();
	}
	
	public void setAuthor(String author){
		_model.setAuthor(author);
		notifyAuthorChanged();
	}
	
	public void setTempo(int tempo){
		_model.setTempo(tempo);
		notifyTempoChanged();
	}

	public void setComment(String comment){
		_model.setComment(comment);
		notifyCommentChanged();
	}
	
	public void setCopyright(String copyright){
		_model.setCopyright(copyright);
		notifyCopyrightChanged();
	}
	
	public void setDate(Date date){
		_model.setDate(date);
		notifyDateChanged();
	}
	
	public void setKey(Key key){
		_model.setKey(key);
		notifyKeyChanged();
	}

	private void notifyDateChanged(){
		Iterator<MetaModelListener> it = _listeners.iterator();
		
		while(it.hasNext()){
			MetaModelListener listener = it.next();
			listener.dateChanged(new ValueChangeEvent(this));
		}		
	}
	
	private void notifyKeyChanged(){
		Iterator<MetaModelListener> it = _listeners.iterator();
		
		while(it.hasNext()){
			MetaModelListener listener = it.next();
			listener.keyChanged(new ValueChangeEvent(this));
		}		
	}
	
	private void notifyAuthorChanged(){
		Iterator<MetaModelListener> it = _listeners.iterator();
		
		while(it.hasNext()){
			MetaModelListener listener = it.next();
			listener.authorChanged(new ValueChangeEvent(this));
		}		
	}
	
	private void notifyCommentChanged(){
		Iterator<MetaModelListener> it = _listeners.iterator();
		
		while(it.hasNext()){
			MetaModelListener listener = it.next();
			listener.commentChanged(new ValueChangeEvent(this));
		}		
	}
	
	private void notifyCopyrightChanged(){
		Iterator<MetaModelListener> it = _listeners.iterator();
		
		while(it.hasNext()){
			MetaModelListener listener = it.next();
			listener.copyrightChanged(new ValueChangeEvent(this));
		}		
	}
	
	private void notifyTempoChanged(){
		Iterator<MetaModelListener> it = _listeners.iterator();
		
		while(it.hasNext()){
			MetaModelListener listener = it.next();
			listener.tempoChanged(new ValueChangeEvent(this));
		}		
	}
	
	private void notifyTitleChanged(){
		Iterator<MetaModelListener> it = _listeners.iterator();
		
		while(it.hasNext()){
			MetaModelListener listener = it.next();
			listener.titleChanged(new ValueChangeEvent(this));
		}		
	}
	
	private void notifyAllToListeners() {
		Iterator<MetaModelListener> it = _listeners.iterator();
		
		while(it.hasNext()){
			MetaModelListener listener = it.next();
			listener.modelChanged(new ValueChangeEvent(this));
		}
	}
	
	public void addListener(MetaModelListener listener){_listeners.add(listener);}
	public void deleteListener(MetaModelListener listener){_listeners.remove(listener);}
}

package etc;

public interface MeasureModelListener {
	void modelChanged(ValueChangeEvent e);
}

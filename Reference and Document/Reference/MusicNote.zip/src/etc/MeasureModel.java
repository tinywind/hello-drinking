package etc;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import composition.Measure;
import composition.Note;

public class MeasureModel {
	private MidiModel _midiModel;
	private Measure _model;
	private List<MeasureModelListener> _listeners;

	public MeasureModel(MidiModel midi, Measure model){
		_midiModel = midi;
		_model = model;
		_listeners = new ArrayList<MeasureModelListener>();		
	}

	public MeasureModel(Measure model){
		_model = model;
		_listeners = new ArrayList<MeasureModelListener>();
	}

	public void addListener(MeasureModelListener listener){
		_listeners.add(listener);	
	}

	public MidiModel getMidiModel(){
		return _midiModel;
	}

	public void setModel(Measure model){
		_model = model;
		notifyChanged();
	}

	public Measure getModel(){
		return _model;
	}

	private void notifyChanged() {
		Iterator<MeasureModelListener> it = _listeners.iterator();
		while(it.hasNext()){
			it.next().modelChanged(new ValueChangeEvent(this));
		}
	}

	public boolean removeNote(Note note){
		if(_model.removeNote(note)){
			if(_model.size()==0 && _midiModel!=null)
				_midiModel.removeMeasure(_model);
			notifyChanged();
			return true;
		}
		return false;
	}

	public void addNote(int index, Note note){
		_model.add(index, note);
		notifyChanged();
	}

	public void changeNote(Note destination, Note source){
		_model.changeNote(destination, source);
		notifyChanged();		
	}

	public boolean insertNote(int index, int pitch){
		Note temp = null;
		int code = 1;
		
		if(index==0)
			temp = _model.get(index);
		else
			temp = _model.get(index-1);

		if(temp != null)
			if(!temp.change(code = temp.getCode()*2))
				return false;

		_model.add(index, new Note(pitch, code));
		notifyChanged();
		return true;
	}

	public void removeListener(MeasureModelListener listener) {
		_listeners.remove(listener);
	}
}

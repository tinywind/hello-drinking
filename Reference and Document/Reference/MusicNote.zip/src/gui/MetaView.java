package gui;

import composition.Note;
import composition.Note.Type;
import etc.MetaModel;
import etc.MetaModelListener;
import etc.ValueChangeEvent;


import android.content.Context;
import android.util.AttributeSet;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MetaView extends LinearLayout implements MetaModelListener{
	private static final int WRAP_CONTENT = LinearLayout.LayoutParams.WRAP_CONTENT;
	private static final int FILL_PARENT = LinearLayout.LayoutParams.FILL_PARENT;
	
	private MetaModel _model;
	private TextView _textTitle;
	private TextView _textTempo;
	
	public MetaView(Context context) {this(context, null);}
	public MetaView(Context context, AttributeSet attrs) {
		super(context, attrs);		
		
		LinearLayout linearTitle = new LinearLayout(context);
		LinearLayout linearDown = new LinearLayout(context);
		
		linearTitle.setLayoutParams(new LinearLayout.LayoutParams(FILL_PARENT, WRAP_CONTENT));
		linearDown.setLayoutParams(new LinearLayout.LayoutParams(FILL_PARENT, WRAP_CONTENT));
		linearDown.setOrientation(LinearLayout.HORIZONTAL);
		
		addView(linearTitle);
		addView(linearDown);

		LinearLayout.LayoutParams downComponentParam= new LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT);
		downComponentParam.weight = 1;
		
		LinearLayout linearTempo = new LinearLayout(context);
		linearTempo.setLayoutParams(downComponentParam);		
		LinearLayout linearAuthor = new LinearLayout(context);
		linearAuthor.setLayoutParams(downComponentParam);
		
		linearDown.addView(linearTempo);
		linearDown.addView(linearAuthor);

		_textTitle = new TextView(context);
		_textTitle.setLayoutParams(new LinearLayout.LayoutParams(FILL_PARENT, WRAP_CONTENT));

		_textTempo = new TextView(context);
		_textTempo.setLayoutParams(new LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT));
		ImageView noteImage = new ImageView(context);
		noteImage.setLayoutParams(new LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT));
		noteImage.setImageBitmap(Note.NoteImageManager.getImageInfo(Type.QUARTHER).getImage());
		
		linearTitle.addView(_textTitle);
		linearTempo.addView(noteImage);
		linearTempo.addView(_textTempo);
	}
		
	public void setModel(MetaModel model){
		_model = model;
		_model.addListener(this);
		modelChanged(new ValueChangeEvent(_model));
	}	

	@Override public void modelChanged(ValueChangeEvent e) {
		titleChanged(e);
		authorChanged(e);
		tempoChanged(e);
	}	
	@Override public void titleChanged(ValueChangeEvent e) {
		String title = ((MetaModel)e.getSource()).getMeta().getTitle();
		if(title.equals(""))
			title = "UnTitle";
		_textTitle.setText(title);
	}
	@Override public void authorChanged(ValueChangeEvent e) {
	}
	@Override public void tempoChanged(ValueChangeEvent e) {
		String tempo =((MetaModel)e.getSource()).getMeta().getTempo()+"";
		_textTempo.setText(tempo);
	}
	@Override public void keyChanged(ValueChangeEvent e) {
	}
	
	@Override public void commentChanged(ValueChangeEvent e) {}
	@Override public void copyrightChanged(ValueChangeEvent e) {}
	@Override public void dateChanged(ValueChangeEvent e) {}
}
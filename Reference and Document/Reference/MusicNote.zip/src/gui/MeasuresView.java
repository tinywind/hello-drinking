package gui;

import java.util.Iterator;
import java.util.List;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;

import composition.Measure;

import etc.MeasureModelListener;
import etc.MidiModel;
import etc.MidiModelListener;
import etc.ValueChangeEvent;

public class MeasuresView extends LinearLayout implements MidiModelListener, MeasureModelListener{
	private static final int NUMBER_VIEW_IN_1LINEAR = 4;

	private MidiModel _model;
	private MeasureView _measureViewLast;

	public MeasuresView(Context context) {this(context, null);}
	public MeasuresView(Context context, AttributeSet attrs) {
		super(context, attrs);
	}
	public void setModel(MidiModel midiModel) {
		_model = midiModel;
		_model.addListener(this);
		midiChanged(new ValueChangeEvent(_model));
	}

	@Override
	public void midiChanged(ValueChangeEvent e) {
		removeAllViews();

		List<Measure> list = ((MidiModel)e.getSource()).getMidiItem().getMeasures();
		Iterator<Measure> it = list.iterator();
		LinearLayout linear = null;
		int index = 0;
		for(;it.hasNext();index++){
			if(index%NUMBER_VIEW_IN_1LINEAR ==0){
				if(linear!=null)
					addView(linear);

				linear = new LinearLayout(getContext());
				linear.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT));
				linear.setOrientation(LinearLayout.HORIZONTAL);
			}

			MeasureView view = new MeasureView(getContext());
			view.setMeasure(_model, it.next());
			LayoutParams param = new LayoutParams(MeasureView.WIDTH_MEASURE,MeasureView.HEIGHT_MEASURE); 
			view.setLayoutParams(param);
			linear.addView(view,index);
		}

		_measureViewLast = new MeasureView(getContext());
		LayoutParams param = new LayoutParams(MeasureView.WIDTH_MEASURE,MeasureView.HEIGHT_MEASURE); 
		_measureViewLast.setLayoutParams(param);
		_measureViewLast.setMeasure(new Measure(), this);

		if(index%NUMBER_VIEW_IN_1LINEAR ==0){
			if(linear!=null)
				addView(linear);
			linear = new LinearLayout(getContext());
			linear.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT));
			linear.setOrientation(LinearLayout.HORIZONTAL);
		}
		linear.addView(_measureViewLast);
		addView(linear);
	}

	@Override
	public void measureChanged(ValueChangeEvent e) {
		((MeasureView)getChildAt(e.getState())).setMeasure(_model, 
				((MidiModel)e.getSource()).getMidiItem().getMeasure(e.getState()));
	}
	@Override
	public void measureRemoved(ValueChangeEvent e) {
		int indexOfLinear = e.getState()/NUMBER_VIEW_IN_1LINEAR;
		int indexOfViewInLinear = e.getState()%NUMBER_VIEW_IN_1LINEAR;
		((LinearLayout)getChildAt(indexOfLinear)).removeViewAt(indexOfViewInLinear);
		
		for(;indexOfLinear < getChildCount()-1;indexOfLinear++){
			View view = ((LinearLayout)getChildAt(indexOfLinear+1)).getChildAt(0);
			((LinearLayout)getChildAt(indexOfLinear+1)).removeViewAt(0);
			((LinearLayout)getChildAt(indexOfLinear)).addView(view);
		}
	}
	@Override
	public void measureAdded(ValueChangeEvent e) {
		List<Measure> measures = ((MidiModel)e.getSource()).getMidiItem().getMeasures();
		MeasureView view = new MeasureView(getContext());
		view.setMeasure(_model, measures.get(measures.size()-1));
		LayoutParams param = new LayoutParams(MeasureView.WIDTH_MEASURE,MeasureView.HEIGHT_MEASURE); 
		view.setLayoutParams(param);

		LinearLayout lastLinear = ((LinearLayout)getChildAt(getChildCount()-1));
		if(lastLinear.getChildCount()%NUMBER_VIEW_IN_1LINEAR==0){
			View emptyView = lastLinear.getChildAt(NUMBER_VIEW_IN_1LINEAR-1);
			lastLinear.removeView(emptyView);
			lastLinear.addView(view);

			LinearLayout linear = new LinearLayout(getContext());
			linear.setLayoutParams(new LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT));
			linear.setOrientation(LinearLayout.HORIZONTAL);
			linear.addView(emptyView);
			addView(linear);
		}else{
			lastLinear.addView(view, lastLinear.getChildCount()-1);
		}		
	}

	// _measureViewLast�� ���� �ٲ� ȣ��. 
	// ������ MeasureView�� MeasureView ������ modelChanged()�޼��带 ȣ��.
	@Override
	public void modelChanged(ValueChangeEvent e) {
		_model.addMeasure(_measureViewLast.getModel().getModel());
		_measureViewLast.setMeasure(new Measure(), this);
	}
}
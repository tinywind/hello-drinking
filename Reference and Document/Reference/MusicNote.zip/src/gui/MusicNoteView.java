package gui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Point;
import android.util.AttributeSet;
import android.widget.FrameLayout;

public class MusicNoteView extends FrameLayout{
	private float zoomLevel;
	private Point currentPoint;
	
	public MusicNoteView(Context context) {
		this(context, null, 0);
	}	
	public MusicNoteView(Context context, AttributeSet attrs) {
		this(context, attrs, 0);
	}	
	public MusicNoteView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		
		zoomLevel = 1;
		currentPoint = new Point(0,0);
	}
	@Override
	protected void onDraw(Canvas canvas) {
		canvas.translate(currentPoint.x, currentPoint.y);
		canvas.scale(zoomLevel, zoomLevel);
	}
}
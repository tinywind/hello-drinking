package gui;

import java.util.List;

import android.R;
import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.Config;
import android.util.Log;
import android.view.FocusFinder;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.animation.AnimationUtils;
import android.widget.FrameLayout;
import android.widget.Scroller;

public class FullScrollView extends FrameLayout {
	static final String TAG = "FullScrollView";
	static final boolean localLOGV = false || Config.LOGV;

	private static final int ANIMATED_SCROLL_GAP = 250;
	private static final float MAX_SCROLL_FACTOR = 0.5f;
	public static int mScrollX;
	public static int mScrollY;
	private long mLastScroll;
	private final Rect mTempRect = new Rect();
	private Scroller mScroller;
	private boolean mScrollViewMovedFocus;
	private float mLastMotionX;
	private float mLastMotionY;
	private boolean mIsLayoutDirty = true;
	private View mChildToScrollTo = null;
	private boolean mIsBeingDraggedX = false;
	private boolean mIsBeingDraggedY = false;
	private VelocityTracker mVelocityTracker;
	private boolean mFillViewportX;
	private boolean mFillViewportY;
	private boolean mSmoothScrollingEnabled = true;

	public FullScrollView(Context context) {
		this(context, null);
	}

	public FullScrollView(Context context, AttributeSet attrs) {
		this(context, attrs, R.attr.scrollViewStyle);
	}

	public FullScrollView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		initScrollView();
	}

	@Override
	protected float getLeftFadingEdgeStrength() {
		if (getChildCount() == 0) 
			return 0.0f;

		final int width = getHorizontalFadingEdgeLength();
		if (mScrollX < width) 
			return mScrollX / (float) width;

		return 1.0f;
	}

	@Override
	protected float getRightFadingEdgeStrength() {
		if (getChildCount() == 0) 
			return 0.0f;

		final int width = getHorizontalFadingEdgeLength();
		final int right = getChildAt(0).getRight();
		final int span = right - mScrollX - getWidth();
		if (span < width) 
			return span / (float) width;

		return 1.0f;
	}

	@Override
	protected float getTopFadingEdgeStrength() {
		if (getChildCount() == 0) 
			return 0.0f;

		final int length = getVerticalFadingEdgeLength();
		if (mScrollY < length) 
			return mScrollY / (float) length;

		return 1.0f;
	}

	@Override
	protected float getBottomFadingEdgeStrength() {
		if (getChildCount() == 0) {
			return 0.0f;
		}

		final int length = getVerticalFadingEdgeLength();
		final int bottom = getChildAt(0).getBottom();
		final int span = bottom - mScrollY - getHeight();
		if (span < length) 
			return span / (float) length;

		return 1.0f;
	}

	public int getMaxScrollAmountY() {
		return (int) (MAX_SCROLL_FACTOR * (getBottom() - getTop()));
	}

	public int getMaxScrollAmountX() {
		return (int) (MAX_SCROLL_FACTOR * (getRight() - getLeft()));
	}

	private void initScrollView() {
		mScroller = new Scroller(getContext());
		setFocusable(true);
		setDescendantFocusability(FOCUS_AFTER_DESCENDANTS);
		setWillNotDraw(false);
	}

	@Override
	public void addView(View child) {
		if (getChildCount() > 0) {
			throw new IllegalStateException("ScrollView can host only one direct child");
		}

		super.addView(child);
	}

	@Override
	public void addView(View child, int index) {
		if (getChildCount() > 0) {
			throw new IllegalStateException("ScrollView can host only one direct child");
		}

		super.addView(child, index);
	}

	@Override
	public void addView(View child, ViewGroup.LayoutParams params) {
		if (getChildCount() > 0) {
			throw new IllegalStateException("ScrollView can host only one direct child");
		}

		super.addView(child, params);
	}

	@Override
	public void addView(View child, int index, ViewGroup.LayoutParams params) {
		if (getChildCount() > 0) {
			throw new IllegalStateException("ScrollView can host only one direct child");
		}

		super.addView(child, index, params);
	}

	private boolean canScrollX() {
		View child = getChildAt(0);
		if (child != null) {
			int childWidth = child.getWidth();
			return getWidth() < childWidth + getPaddingLeft() + getPaddingRight();
		}
		return false;
	}

	private boolean canScrollY() {
		View child = getChildAt(0);
		if (child != null) {
			int childHeight = child.getHeight();
			return getHeight() < childHeight + getPaddingTop() + getPaddingBottom();
		}
		return false;
	}

	public boolean isFillViewportX() {
		return mFillViewportX;
	}

	public boolean isFillViewportY() {
		return mFillViewportY;
	}

	public void setFillViewportX(boolean fillViewportX) {
		if (fillViewportX != mFillViewportX) {
			mFillViewportX = fillViewportX;
			requestLayout();
		}
	}

	public void setFillViewportY(boolean fillViewportY) {
		if (fillViewportY != mFillViewportY) {
			mFillViewportY = fillViewportY;
			requestLayout();
		}
	}

	public boolean isSmoothScrollingEnabled() {
		return mSmoothScrollingEnabled;
	}

	public void setSmoothScrollingEnabled(boolean smoothScrollingEnabled) {
		mSmoothScrollingEnabled = smoothScrollingEnabled;
	}

	@Override
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		super.onMeasure(widthMeasureSpec, heightMeasureSpec);

		if (!mFillViewportX&&!mFillViewportY) 
			return;

		final int widthMode = MeasureSpec.getMode(widthMeasureSpec);
		final int heightMode = MeasureSpec.getMode(heightMeasureSpec);
		if (heightMode == MeasureSpec.UNSPECIFIED && widthMode == MeasureSpec.UNSPECIFIED) {
			return;
		}

		final View child = getChildAt(0);
		int width = getMeasuredWidth();
		int height = getMeasuredHeight();
		if (child.getMeasuredWidth() < width && child.getMeasuredHeight() < height && heightMode != MeasureSpec.UNSPECIFIED && widthMode != MeasureSpec.UNSPECIFIED && mFillViewportX&&mFillViewportY) {

			width -= getPaddingLeft();
			width -= getPaddingRight();
			int childWidthMeasureSpec = MeasureSpec.makeMeasureSpec(width, MeasureSpec.EXACTLY);
			height -= getPaddingTop();
			height -= getPaddingBottom();
			int childHeightMeasureSpec = MeasureSpec.makeMeasureSpec(height, MeasureSpec.EXACTLY);

			child.measure(childWidthMeasureSpec, childHeightMeasureSpec);
		}else if (child.getMeasuredHeight() < height && heightMode != MeasureSpec.UNSPECIFIED && mFillViewportY) {
			final FrameLayout.LayoutParams lp = (LayoutParams) child.getLayoutParams();

			int childWidthMeasureSpec = getChildMeasureSpec(widthMeasureSpec, getPaddingLeft()
					+ getPaddingRight(), lp.width);
			height -= getPaddingTop();
			height -= getPaddingBottom();
			int childHeightMeasureSpec = MeasureSpec.makeMeasureSpec(height, MeasureSpec.EXACTLY);

			child.measure(childWidthMeasureSpec, childHeightMeasureSpec);
		}else if (child.getMeasuredWidth() < width && widthMode != MeasureSpec.UNSPECIFIED && mFillViewportX) {
			final FrameLayout.LayoutParams lp = (LayoutParams) child.getLayoutParams();

			int childHeightMeasureSpec = getChildMeasureSpec(heightMeasureSpec, getPaddingTop()
					+ getPaddingBottom(), lp.height);
			width -= getPaddingLeft();
			width -= getPaddingRight();
			int childWidthMeasureSpec = MeasureSpec.makeMeasureSpec(width, MeasureSpec.EXACTLY);

			child.measure(childWidthMeasureSpec, childHeightMeasureSpec);
		}
	}

	@Override
	public boolean dispatchKeyEvent(KeyEvent event) {
		boolean handled = super.dispatchKeyEvent(event);
		if (handled) 
			return true;
		return executeKeyEvent(event);
	}

	public boolean executeKeyEvent(KeyEvent event) {
		mTempRect.setEmpty();

		if (!canScrollX()||!canScrollY()) {
			if (isFocused()) {
				View currentFocused = findFocus();
				if (currentFocused == this) currentFocused = null;
				View nextFocused = FocusFinder.getInstance().findNextFocus(this,
						currentFocused, View.FOCUS_DOWN);
				return nextFocused != null
				&& nextFocused != this
				&& nextFocused.requestFocus(View.FOCUS_DOWN);
			}
			return false;
		}

		boolean handled = false;
		if(canScrollY()){
			if (event.getAction() == KeyEvent.ACTION_DOWN) {
				switch (event.getKeyCode()) {
				case KeyEvent.KEYCODE_DPAD_UP:
					if (!event.isAltPressed()) {
						handled = arrowScroll(View.FOCUS_UP);
					} else {
						handled = fullScroll(View.FOCUS_UP);
					}
					break;
				case KeyEvent.KEYCODE_DPAD_DOWN:
					if (!event.isAltPressed()) {
						handled = arrowScroll(View.FOCUS_DOWN);
					} else {
						handled = fullScroll(View.FOCUS_DOWN);
					}
					break;
				case KeyEvent.KEYCODE_SPACE:
					pageScroll(event.isShiftPressed() ? View.FOCUS_UP : View.FOCUS_DOWN);
					break;
				}
			}
		}
		if(canScrollX()){
			if (event.getAction() == KeyEvent.ACTION_DOWN) {
				switch (event.getKeyCode()) {
				case KeyEvent.KEYCODE_DPAD_LEFT:
					if (!event.isAltPressed()) {
						handled = arrowScroll(View.FOCUS_LEFT);
					} else {
						handled = fullScroll(View.FOCUS_LEFT);
					}
					break;
				case KeyEvent.KEYCODE_DPAD_RIGHT:
					if (!event.isAltPressed()) {
						handled = arrowScroll(View.FOCUS_RIGHT);
					} else {
						handled = fullScroll(View.FOCUS_RIGHT);
					}
					break;
				}
			}
		}

		return handled;
	}

	@Override
	public boolean onInterceptTouchEvent(MotionEvent ev) {
		final int action = ev.getAction();
		if ((action == MotionEvent.ACTION_MOVE) && (mIsBeingDraggedX||mIsBeingDraggedY)) 
			return true;

		if (!canScrollX()) mIsBeingDraggedX = false;
		if (!canScrollY()) mIsBeingDraggedY = false;

		if (!canScrollY()&&!canScrollX()) 
			return false;

		final float x = ev.getX();
		final float y = ev.getY();

		switch (action) {
		case MotionEvent.ACTION_MOVE:
			final int xDiff = (int) Math.abs(x - mLastMotionX);
			if (xDiff > ViewConfiguration.getTouchSlop()) mIsBeingDraggedX = true;

			final int yDiff = (int) Math.abs(y - mLastMotionY);
			if (yDiff > ViewConfiguration.getTouchSlop())  mIsBeingDraggedY = true;

			break;
		case MotionEvent.ACTION_DOWN:
			mLastMotionX = x;
			mLastMotionY = y;
			mIsBeingDraggedX = !mScroller.isFinished();
			mIsBeingDraggedY = !mScroller.isFinished();
			break;

		case MotionEvent.ACTION_CANCEL:
		case MotionEvent.ACTION_UP:
			mIsBeingDraggedX = false;
			mIsBeingDraggedY = false;
			break;
		}
		return (mIsBeingDraggedX||mIsBeingDraggedY);
	}

	@Override
	public boolean onTouchEvent(MotionEvent ev) {
		if (ev.getAction() == MotionEvent.ACTION_DOWN && ev.getEdgeFlags() != 0)
			return false;
		if (!canScrollX()&&!canScrollY())
			return false;

		if (mVelocityTracker == null) 
			mVelocityTracker = VelocityTracker.obtain();

		mVelocityTracker.addMovement(ev);

		final int action = ev.getAction();
		final float x = ev.getX();
		final float y = ev.getY();

		switch (action) {
		case MotionEvent.ACTION_DOWN:
			if (!mScroller.isFinished()) 
				mScroller.abortAnimation();
			break;
		case MotionEvent.ACTION_MOVE:
			final int deltaX = (int) (mLastMotionX - x);
			mLastMotionX = x;
			final int deltaY = (int) (mLastMotionY - y);
			mLastMotionY = y;

			if(localLOGV) Log.v(TAG, "onTouchEvent ActionMove deltaX="+deltaX+" deltaY="+deltaY);

			if (deltaX < 0) {
				if (mScrollX >= 0) {
					scrollBy(deltaX, 0);
				}
			} else if (deltaX > 0) {
				final int rightEdge = getWidth() - getPaddingRight();
				final int availableToScroll = getChildAt(0).getRight() - mScrollX - rightEdge;
				if (availableToScroll > 0) {
					scrollBy(Math.min(availableToScroll, deltaX), 0);
				}
			}

			if (deltaY < 0) {
				if (mScrollY >= 0) {//FIX Changed, don't know why, pjv.
					scrollBy(0, deltaY);
				}
			} else if (deltaY > 0) {
				final int bottomEdge = getHeight() - getPaddingBottom();
				final int availableToScroll = getChildAt(0).getBottom() - mScrollY - bottomEdge;
				if (availableToScroll > 0) {
					scrollBy(0, Math.min(availableToScroll, deltaY));
				}
			}
			break;
		case MotionEvent.ACTION_UP:
			final VelocityTracker velocityTracker = mVelocityTracker;
			velocityTracker.computeCurrentVelocity(1000);
			int initialVelocityX = (int) velocityTracker.getXVelocity();
			int initialVelocityY = (int) velocityTracker.getYVelocity();

			if ((Math.abs(initialVelocityX) > ViewConfiguration.getMinimumFlingVelocity()) &&
					(getChildCount() > 0)) {
				flingX(-initialVelocityX);
			}

			if ((Math.abs(initialVelocityY) > ViewConfiguration.getMinimumFlingVelocity()) &&
					(getChildCount() > 0)) {
				flingY(-initialVelocityY);
			}

			if (mVelocityTracker != null) {
				mVelocityTracker.recycle();
				mVelocityTracker = null;
			}
		}
		return true;
	}

	private View findFocusableViewInMyBoundsX(final boolean leftFocus,
			final int left, View preferredFocusable) {
		final int fadingEdgeLength = getHorizontalFadingEdgeLength() / 2;
		final int leftWithoutFadingEdge = left + fadingEdgeLength;
		final int rightWithoutFadingEdge = left + getWidth() - fadingEdgeLength;

		if ((preferredFocusable != null)
				&& (preferredFocusable.getLeft() < rightWithoutFadingEdge)
				&& (preferredFocusable.getRight() > leftWithoutFadingEdge)) {
			return preferredFocusable;
		}

		return findFocusableViewInBoundsX(leftFocus, leftWithoutFadingEdge,
				rightWithoutFadingEdge);
	}

	private View findFocusableViewInMyBoundsY(final boolean topFocus,
			final int top, View preferredFocusable) {
		final int fadingEdgeLength = getVerticalFadingEdgeLength() / 2;
		final int topWithoutFadingEdge = top + fadingEdgeLength;
		final int bottomWithoutFadingEdge = top + getHeight() - fadingEdgeLength;

		if ((preferredFocusable != null)
				&& (preferredFocusable.getTop() < bottomWithoutFadingEdge)
				&& (preferredFocusable.getBottom() > topWithoutFadingEdge)) {
			return preferredFocusable;
		}

		return findFocusableViewInBoundsY(topFocus, topWithoutFadingEdge,
				bottomWithoutFadingEdge);
	}

	private View findFocusableViewInBoundsX(boolean leftFocus, int left, int right) {
		List<View> focusables = getFocusables(View.FOCUS_FORWARD);
		View focusCandidate = null;

		boolean foundFullyContainedFocusable = false;

		int count = focusables.size();
		for (int i = 0; i < count; i++) {
			View view = focusables.get(i);
			int viewLeft = view.getLeft();
			int viewRight = view.getRight();

			if (left < viewRight && viewLeft < right) {
				final boolean viewIsFullyContained = (left < viewLeft) && (viewRight < right);

				if (focusCandidate == null) {
					focusCandidate = view;
					foundFullyContainedFocusable = viewIsFullyContained;
				} else {
					final boolean viewIsCloserToBoundary =
						(leftFocus && viewLeft < focusCandidate.getLeft()) ||
						(!leftFocus && viewRight > focusCandidate.getRight());

					if (foundFullyContainedFocusable) 
						if (viewIsFullyContained && viewIsCloserToBoundary) 
							focusCandidate = view;
						else 
							if (viewIsFullyContained) {
								focusCandidate = view;
								foundFullyContainedFocusable = true;
							} else if (viewIsCloserToBoundary) 
								focusCandidate = view;
				}
			}
		}

		return focusCandidate;
	}

	private View findFocusableViewInBoundsY(boolean topFocus, int top, int bottom) {
		List<View> focusables = getFocusables(View.FOCUS_FORWARD);
		View focusCandidate = null;

		boolean foundFullyContainedFocusable = false;

		int count = focusables.size();
		for (int i = 0; i < count; i++) {
			View view = focusables.get(i);
			int viewTop = view.getTop();
			int viewBottom = view.getBottom();

			if (top < viewBottom && viewTop < bottom) {
				final boolean viewIsFullyContained = (top < viewTop) &&
				(viewBottom < bottom);

				if (focusCandidate == null) {
					focusCandidate = view;
					foundFullyContainedFocusable = viewIsFullyContained;
				} else {
					final boolean viewIsCloserToBoundary =
						(topFocus && viewTop < focusCandidate.getTop()) || 
						(!topFocus && viewBottom > focusCandidate.getBottom());

					if (foundFullyContainedFocusable) {
						if (viewIsFullyContained && viewIsCloserToBoundary) 
							focusCandidate = view;
					} else 
						if (viewIsFullyContained) {
							focusCandidate = view;
							foundFullyContainedFocusable = true;
						} else if (viewIsCloserToBoundary) 
							focusCandidate = view;
				}
			}
		}

		return focusCandidate;
	}

	public boolean pageScroll(int direction) {
		boolean down = direction == View.FOCUS_DOWN;
		int height = getHeight();

		if (down) {
			mTempRect.top = getScrollY() + height;
			int count = getChildCount();
			if (count > 0) {
				View view = getChildAt(count - 1);
				if (mTempRect.top + height > view.getBottom()) {
					mTempRect.top = view.getBottom() - height;
				}
			}
		} else {
			mTempRect.top = getScrollY() - height;
			if (mTempRect.top < 0) {
				mTempRect.top = 0;
			}
		}
		mTempRect.bottom = mTempRect.top + height;

		return scrollAndFocus(direction, mTempRect.top, mTempRect.bottom);
	}

	public boolean fullScroll(int direction) {
		boolean down = direction == View.FOCUS_DOWN;
		int height = getHeight();

		mTempRect.top = 0;
		mTempRect.bottom = height;

		if (down) {
			int count = getChildCount();
			if (count > 0) {
				View view = getChildAt(count - 1);
				mTempRect.bottom = view.getBottom();
				mTempRect.top = mTempRect.bottom - height;
			}
		}

		return scrollAndFocus(direction, mTempRect.top, mTempRect.bottom);
	}

	private boolean scrollAndFocus(int direction, int top, int bottom) {
		boolean handled = true;

		int height = getHeight();
		int containerTop = getScrollY();
		int containerBottom = containerTop + height;
		boolean up = direction == View.FOCUS_UP;

		View newFocused = findFocusableViewInBoundsY(up, top, bottom);//TODO
		if (newFocused == null) {
			newFocused = this;
		}

		if (top >= containerTop && bottom <= containerBottom) {
			handled = false;
		} else {
			int delta = up ? (top - containerTop) : (bottom - containerBottom);
			doScrollY(delta);
		}

		if (newFocused != findFocus() && newFocused.requestFocus(direction)) {
			mScrollViewMovedFocus = true;
			mScrollViewMovedFocus = false;
		}

		return handled;
	}

	public boolean arrowScroll(int direction) {

		View currentFocused = findFocus();
		if (currentFocused == this) currentFocused = null;

		View nextFocused = FocusFinder.getInstance().findNextFocus(this, currentFocused, direction);

		final int maxJumpX = getMaxScrollAmountX();
		final int maxJumpY = getMaxScrollAmountY();

		if (nextFocused != null && isWithinDeltaOfScreenX(nextFocused, maxJumpX) && isWithinDeltaOfScreenY(nextFocused, maxJumpY)) {//TODO
			nextFocused.getDrawingRect(mTempRect);
			offsetDescendantRectToMyCoords(nextFocused, mTempRect);
			int scrollDeltaX = computeScrollDeltaToGetChildRectOnScreenX(mTempRect);
			doScrollX(scrollDeltaX);
			int scrollDeltaY = computeScrollDeltaToGetChildRectOnScreenY(mTempRect);
			doScrollY(scrollDeltaY);
			nextFocused.requestFocus(direction);
		} else {
			// no new focus
			int scrollDeltaX = maxJumpX;
			int scrollDeltaY = maxJumpY;

			if (direction == View.FOCUS_UP && getScrollX() < scrollDeltaX) {
				scrollDeltaX = getScrollX();
			} else if (direction == View.FOCUS_DOWN) {

				int daRight = getChildAt(getChildCount() - 1).getRight();

				int screenRight = getScrollX() + getWidth();

				if (daRight - screenRight < maxJumpX) {
					scrollDeltaX = daRight - screenRight;
				}
			}
			if (direction == View.FOCUS_UP && getScrollY() < scrollDeltaY) {
				scrollDeltaY = getScrollY();
			} else if (direction == View.FOCUS_DOWN) {

				int daBottom = getChildAt(getChildCount() - 1).getBottom();

				int screenBottom = getScrollY() + getHeight();

				if (daBottom - screenBottom < maxJumpY) {
					scrollDeltaY = daBottom - screenBottom;
				}
			}
			if (scrollDeltaX == 0 && scrollDeltaY == 0) {
				return false;
			}else if (scrollDeltaX == 0) {
				doScrollY(direction == View.FOCUS_DOWN ? scrollDeltaY : -scrollDeltaY);
			}else if (scrollDeltaY == 0) {
				doScrollX(direction == View.FOCUS_DOWN ? scrollDeltaX : -scrollDeltaX);
			}
		}

		if (currentFocused != null && currentFocused.isFocused()
				&& isOffScreen(currentFocused)) {
			final int descendantFocusability = getDescendantFocusability();  // save
			setDescendantFocusability(ViewGroup.FOCUS_BEFORE_DESCENDANTS);
			requestFocus();
			setDescendantFocusability(descendantFocusability);  // restore
		}
		return true;
	}

	private boolean isOffScreen(View descendant) {
		return !isWithinDeltaOfScreenX(descendant, 0)&&!isWithinDeltaOfScreenY(descendant, 0);
	}

	private boolean isWithinDeltaOfScreenX(View descendant, int delta) {
		descendant.getDrawingRect(mTempRect);
		offsetDescendantRectToMyCoords(descendant, mTempRect);

		return (mTempRect.right + delta) >= getScrollX()
		&& (mTempRect.left - delta) <= (getScrollX() + getWidth());
	}

	private boolean isWithinDeltaOfScreenY(View descendant, int delta) {
		descendant.getDrawingRect(mTempRect);
		offsetDescendantRectToMyCoords(descendant, mTempRect);

		return (mTempRect.bottom + delta) >= getScrollY()
		&& (mTempRect.top - delta) <= (getScrollY() + getHeight());
	}

	private void doScrollX(int delta) {
		if (delta != 0) {
			if (mSmoothScrollingEnabled) {
				smoothScrollBy(delta, 0);
			} else {
				scrollBy(delta, 0);
			}
		}
	}

	private void doScrollY(int delta) {
		if (delta != 0) {
			if (mSmoothScrollingEnabled) {
				smoothScrollBy(0, delta);
			} else {
				scrollBy(0, delta);
			}
		}
	}

	public final void smoothScrollBy(int dx, int dy) {
		long duration = AnimationUtils.currentAnimationTimeMillis() - mLastScroll;
		if (duration > ANIMATED_SCROLL_GAP) {
			if (localLOGV) Log.v(TAG, "Smooth scroll: mScrollX=" + mScrollX
					+ " dx=" + dx + "mScrollY=" + mScrollY
					+ " dy=" + dy);
			mScroller.startScroll(mScrollX, mScrollY, dx, dy);
			invalidate();
		} else {
			if (!mScroller.isFinished()) {
				mScroller.abortAnimation();
			}
			if (localLOGV) Log.v(TAG, "Immediate scroll: mScrollX=" + mScrollX
					+ " dx=" + dx + "mScrollY=" + mScrollY
					+ " dy=" + dy);
			scrollBy(dx, dy);
		}
		mLastScroll = AnimationUtils.currentAnimationTimeMillis();
	}

	public final void smoothScrollTo(int x, int y) {
		smoothScrollBy(x - mScrollX, y - mScrollY);
	}

	@Override
	protected int computeHorizontalScrollRange() {
		int count = getChildCount();
		return count == 0 ? getWidth() : (getChildAt(0)).getRight();
	}

	@Override
	protected int computeVerticalScrollRange() {
		int count = getChildCount();
		return count == 0 ? getHeight() : (getChildAt(0)).getBottom();
	}

	@Override
	protected void measureChild(View child, int parentWidthMeasureSpec, int parentHeightMeasureSpec) {
		int childWidthMeasureSpec;
		int childHeightMeasureSpec;

		childWidthMeasureSpec = MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED);

		childHeightMeasureSpec = MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED);

		child.measure(childWidthMeasureSpec, childHeightMeasureSpec);
	}

	@Override
	protected void measureChildWithMargins(View child, int parentWidthMeasureSpec, int widthUsed,
			int parentHeightMeasureSpec, int heightUsed) {
		final MarginLayoutParams lp = (MarginLayoutParams) child.getLayoutParams();

		final int childWidthMeasureSpec = MeasureSpec.makeMeasureSpec(
				lp.leftMargin + lp.rightMargin, MeasureSpec.UNSPECIFIED);
		final int childHeightMeasureSpec = MeasureSpec.makeMeasureSpec(
				lp.topMargin + lp.bottomMargin, MeasureSpec.UNSPECIFIED);

		child.measure(childWidthMeasureSpec, childHeightMeasureSpec);
	}

	@Override
	public void computeScroll() {
		if (mScroller.computeScrollOffset()) {
			int oldX = mScrollX;
			int oldY = mScrollY;
			int x = mScroller.getCurrX();
			int y = mScroller.getCurrY();
			if (getChildCount() > 0) {
				View child = getChildAt(0);
				mScrollX = clamp(x, this.getWidth(), child.getWidth());
				mScrollY = clamp(y, this.getHeight(), child.getHeight());
				if (localLOGV) Log.v(TAG, "mScrollX=" + mScrollX + " x=" + x
						+ " width=" + this.getWidth()
						+ " child width=" + child.getWidth() + " mScrollY=" + mScrollY + " y=" + y
						+ " height=" + this.getHeight()
						+ " child height=" + child.getHeight());
			} else {
				mScrollX = x;
				mScrollY = y;
			}            
			if (oldX != mScrollX || oldY != mScrollY) 
				onScrollChanged(mScrollX, mScrollY, oldX, oldY);

			postInvalidate();
		}
	}

	private void scrollToChild(View child) {
		child.getDrawingRect(mTempRect);
		offsetDescendantRectToMyCoords(child, mTempRect);

		int scrollDeltaX = computeScrollDeltaToGetChildRectOnScreenX(mTempRect);
		int scrollDeltaY = computeScrollDeltaToGetChildRectOnScreenY(mTempRect);

		if (scrollDeltaY != 0 || scrollDeltaX != 0) {
			scrollBy(scrollDeltaX, scrollDeltaY);
		}
	}

	private boolean scrollToChildRect(Rect rect, boolean immediate) {
		final int deltaX = computeScrollDeltaToGetChildRectOnScreenX(rect);
		final int deltaY = computeScrollDeltaToGetChildRectOnScreenY(rect);
		final boolean scroll = deltaX != 0 || deltaY != 0;
		if (scroll) {
			if (immediate) {
				scrollBy(deltaX, deltaY);
			} else {
				smoothScrollBy(deltaX, deltaY);
			}
		}
		return scroll;
	}

	protected int computeScrollDeltaToGetChildRectOnScreenX(Rect rect) {

		int width = getWidth();
		int screenLeft = getScrollX();
		int screenRight = screenLeft + width;

		int fadingEdge = getHorizontalFadingEdgeLength();

		if (rect.left > 0) 							screenLeft += fadingEdge;
		if (rect.right < getChildAt(0).getWidth())	screenRight -= fadingEdge;

		int scrollXDelta = 0;

		if (localLOGV) Log.v(TAG, "child=" + rect.toString()
				+ " screenLeft=" + screenLeft + " screenRight=" + screenRight
				+ " width=" + width);
		if (rect.right > screenRight && rect.left > screenLeft) {
			if (rect.width() > width)	scrollXDelta += (rect.left - screenLeft);
			else 						scrollXDelta += (rect.right - screenRight);

			int right = getChildAt(getChildCount() - 1).getRight();
			int distanceToRight = right - screenRight;
			if (localLOGV) Log.v(TAG, "scrollXDelta=" + scrollXDelta
					+ " distanceToRight=" + distanceToRight);
			scrollXDelta = Math.min(scrollXDelta, distanceToRight);

		} else if (rect.left < screenLeft && rect.right < screenRight) {
			if (rect.width() > width)	scrollXDelta -= (screenRight - rect.right);
			else 						scrollXDelta -= (screenLeft - rect.left);
			scrollXDelta = Math.max(scrollXDelta, -getScrollX());
		}
		return scrollXDelta;
	}

	protected int computeScrollDeltaToGetChildRectOnScreenY(Rect rect) {
		int height = getHeight();
		int screenTop = getScrollY();
		int screenBottom = screenTop + height;

		int fadingEdge = getVerticalFadingEdgeLength();

		if (rect.top > 0)
			screenTop += fadingEdge;

		if (rect.bottom < getChildAt(0).getHeight()) 
			screenBottom -= fadingEdge;

		int scrollYDelta = 0;

		if (localLOGV) Log.v(TAG, "child=" + rect.toString()
				+ " screenTop=" + screenTop + " screenBottom=" + screenBottom
				+ " height=" + height);
		if (rect.bottom > screenBottom && rect.top > screenTop) {
			if (rect.height() > height) 	scrollYDelta += (rect.top - screenTop);
			else 							scrollYDelta += (rect.bottom - screenBottom);

			int bottom = getChildAt(getChildCount() - 1).getBottom();
			int distanceToBottom = bottom - screenBottom;
			if (localLOGV) Log.v(TAG, "scrollYDelta=" + scrollYDelta
					+ " distanceToBottom=" + distanceToBottom);
			scrollYDelta = Math.min(scrollYDelta, distanceToBottom);
		} else if (rect.top < screenTop && rect.bottom < screenBottom) {
			if (rect.height() > height)		scrollYDelta -= (screenBottom - rect.bottom);
			else 							scrollYDelta -= (screenTop - rect.top);
			scrollYDelta = Math.max(scrollYDelta, -getScrollY());
		}
		return scrollYDelta;
	}

	@Override
	public void requestChildFocus(View child, View focused) {
		if (!mScrollViewMovedFocus) {
			if (!mIsLayoutDirty) 	scrollToChild(focused);
			else					mChildToScrollTo = focused;
		}
		super.requestChildFocus(child, focused);
	}

	@Override
	protected boolean onRequestFocusInDescendants(int direction, Rect previouslyFocusedRect) {
		if (direction == View.FOCUS_FORWARD)		direction = View.FOCUS_DOWN;
		else if (direction == View.FOCUS_BACKWARD) 	direction = View.FOCUS_UP;

		final View nextFocus = previouslyFocusedRect == null ?
				FocusFinder.getInstance().findNextFocus(this, null, direction) :
					FocusFinder.getInstance().findNextFocusFromRect(this,previouslyFocusedRect, direction);

				if (nextFocus == null) 		return false;
				if (isOffScreen(nextFocus))	return false;
				return nextFocus.requestFocus(direction, previouslyFocusedRect);
	}    

	@Override
	public boolean requestChildRectangleOnScreen(View child, Rect rectangle,
			boolean immediate) {
		rectangle.offset(child.getLeft() - child.getScrollX(),child.getTop() - child.getScrollY());

		return scrollToChildRect(rectangle, immediate);
	}

	@Override
	public void requestLayout() {
		mIsLayoutDirty = true;
		super.requestLayout();
	}

	@Override
	protected void onLayout(boolean changed, int l, int t, int r, int b) {
		super.onLayout(changed, l, t, r, b);
		mIsLayoutDirty = false;
		if (mChildToScrollTo != null && isViewDescendantOf(mChildToScrollTo, this)) 
			scrollToChild(mChildToScrollTo);
		mChildToScrollTo = null;

		scrollTo(mScrollX, mScrollY);
	}

	@Override
	protected void onSizeChanged(int w, int h, int oldw, int oldh) {
		super.onSizeChanged(w, h, oldw, oldh);

		View currentFocused = findFocus();
		if (null == currentFocused || this == currentFocused)
			return;

		final int maxJumpX = getRight() - getLeft();
		final int maxJumpY = getBottom() - getTop();

		if (isWithinDeltaOfScreenX(currentFocused, maxJumpX)) {
			currentFocused.getDrawingRect(mTempRect);
			offsetDescendantRectToMyCoords(currentFocused, mTempRect);
			int scrollDeltaX = computeScrollDeltaToGetChildRectOnScreenX(mTempRect);
			doScrollX(scrollDeltaX);
		}
		if (isWithinDeltaOfScreenY(currentFocused, maxJumpY)) {
			currentFocused.getDrawingRect(mTempRect);
			offsetDescendantRectToMyCoords(currentFocused, mTempRect);
			int scrollDeltaY = computeScrollDeltaToGetChildRectOnScreenY(mTempRect);
			doScrollY(scrollDeltaY);
		}
	}    

	private boolean isViewDescendantOf(View child, View parent) {
		if (child == parent) {
			return true;
		}

		final ViewParent theParent = child.getParent();
		return (theParent instanceof ViewGroup) && isViewDescendantOf((View) theParent, parent);
	}    

	public void flingX(int velocityX) {
		int width = getWidth();
		int right = getChildAt(getChildCount() - 1).getRight();

		mScroller.fling(mScrollX, mScrollY, velocityX, 0, 0, 0, 0, right - width);

		final boolean movingRight = velocityX > 0;

		View newFocused =
			findFocusableViewInMyBoundsX(movingRight, mScroller.getFinalX(), findFocus());
		if (newFocused == null) {
			newFocused = this;
		}

		if (newFocused != findFocus()
				&& newFocused.requestFocus(movingRight ? View.FOCUS_DOWN : View.FOCUS_UP)) {
			mScrollViewMovedFocus = true;
			mScrollViewMovedFocus = false;
		}

		invalidate();
	}

	public void flingY(int velocityY) {
		int height = getHeight();
		int bottom = getChildAt(getChildCount() - 1).getBottom();

		mScroller.fling(mScrollX, mScrollY, 0, velocityY, 0, 0, 0, bottom - height);

		final boolean movingDown = velocityY > 0;

		View newFocused =
			findFocusableViewInMyBoundsY(movingDown, mScroller.getFinalY(), findFocus());
		if (newFocused == null) 
			newFocused = this;

		if (newFocused != findFocus()
				&& newFocused.requestFocus(movingDown ? View.FOCUS_DOWN : View.FOCUS_UP)) {
			mScrollViewMovedFocus = true;
			mScrollViewMovedFocus = false;
		}

		invalidate();
	}

	public void scrollTo(int x, int y) {
		if (getChildCount() > 0) {
			View child = getChildAt(0);
			x = clamp(x, this.getWidth(), child.getWidth());
			y = clamp(y, this.getHeight(), child.getHeight());
			if (x != mScrollX || y != mScrollY) {
				super.scrollTo(x, y);
				mScrollX=x;//FIX Changed, pjv.
				mScrollY=y;//FIX Changed, pjv.
			}
		}
		if(localLOGV) Log.v(TAG, "scrollTo x="+x+" y="+y);
	}

	private int clamp(int n, int my, int child) {
		if (my >= child || n < 0) return 0;
		if ((my+n) > child) 		return child-my;
		return n;
	}
}

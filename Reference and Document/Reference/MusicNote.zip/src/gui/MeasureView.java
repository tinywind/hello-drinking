package gui;

import java.util.Iterator;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.AbsoluteLayout;
import android.widget.ImageView;

import composition.Measure;
import composition.Note;

import etc.MeasureModel;
import etc.MeasureModelListener;
import etc.MidiModel;
import etc.ValueChangeEvent;

@SuppressWarnings("deprecation")
public class MeasureView extends AbsoluteLayout implements MeasureModelListener, OnTouchListener {
	public static final int WIDTH_MEASURE = 240;
	public static final int HEIGHT_MEASURE = 160;
	private static final int FIRST_LINE_Y = 60;
	private static final int INTERVAL_LINE = 8;
	private static final int HIGHT_END_MEASURE = 4*INTERVAL_LINE;
	private static final int PADDING = 20;
	private static final int HEIGHT_STANDARD_DO = FIRST_LINE_Y + 5*INTERVAL_LINE;

	private MeasureModel _model;

	public MeasureView(Context context) {this(context, null);}
	public MeasureView(Context context, AttributeSet attrs) {
		super(context, attrs);
		setBackgroundColor(Color.WHITE);
		setScrollContainer(true);
		setOnTouchListener(this);
	}	

	public void setMeasure(MidiModel midiModel, Measure measure) {
		_model = new MeasureModel(midiModel, measure);
		_model.addListener(this);
		modelChanged(new ValueChangeEvent(_model));
	}

	public void setMeasure(Measure measure, MeasureModelListener listener) {
		_model = new MeasureModel(measure);
		_model.addListener(listener);
	}

	@Override
	protected void onDraw(Canvas canvas) {
		Paint paint = new Paint();
		paint.setColor(Color.BLACK);

		int currentLineY = FIRST_LINE_Y;
		for(int i=0;i<5;i++){
			canvas.drawLine(0, currentLineY, WIDTH_MEASURE, currentLineY, paint);
			currentLineY += INTERVAL_LINE;
		}
		canvas.drawLine(WIDTH_MEASURE-1, FIRST_LINE_Y, 
				WIDTH_MEASURE-1, FIRST_LINE_Y+HIGHT_END_MEASURE, 
				paint);
	}

	@Override
	public void modelChanged(ValueChangeEvent e) {
		removeAllViews();
		Iterator<Note> it = ((MeasureModel)e.getSource()).getModel().iterator();

		int currentX = PADDING;
		while(it.hasNext()){
			Note note = it.next();
			NoteView view = new NoteView(getContext(),note);
			view.setOnTouchListener(this);
			
			int y = HEIGHT_STANDARD_DO - note.getHeight()*(INTERVAL_LINE/2);

			if(note.getHeight() > 6){
				view.setImageBitmap(note.getConvertedImage());
				y -= (note.getImage().getHeight() - note.getImageCenterPoint().y);
			}else{
				view.setImageBitmap(note.getImage());
				y -= note.getImageCenterPoint().y;
			}
			LayoutParams param = new LayoutParams(
					LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, 
					currentX, y);
			addView(view,param);

			currentX += ((WIDTH_MEASURE - 2*PADDING + 0.0))/(note.getCode());
		}
	}
	
	@Override
	public boolean onTouch(View v, MotionEvent ev) {
		if(v instanceof NoteView){
			((NoteView) v).onTouch();
			return true;
		}		
		
		if(ev.getAction() == MotionEvent.ACTION_UP){
			Iterator<Note> it = _model.getModel().iterator();
			int currentX = PADDING;
			int index = 0;
			while(it.hasNext()){
				if(ev.getX()<currentX)
					break;
				Note note = it.next();
				currentX += ((WIDTH_MEASURE - 2*PADDING + 0.0))/(note.getCode());
				index++;
			}
			int pitch = (int) ((HEIGHT_STANDARD_DO - ev.getY())/(INTERVAL_LINE/2));
			_model.insertNote(index, pitch);
		}
		return true;
	}
	
	public MeasureModel getModel(){
		return _model;
	}
}

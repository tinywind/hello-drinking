package gui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.ImageView;

import composition.Note;

public class NoteView extends ImageView {
	private Note _note;
	private boolean _isSelected = false;
	
	public NoteView(Context context, Note note) {
		super(context);
		_note = note;
		setLayoutParams(new LayoutParams(note.getImage().getWidth(),note.getImage().getHeight()));		
	}

	public void onTouch(){
		_isSelected = true;
		setBackgroundColor(Color.RED);
	}
}

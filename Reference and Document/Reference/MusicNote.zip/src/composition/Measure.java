package composition;

import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import composition.Note.Type;

public class Measure {
	List<Note> notes;

	public Measure(){
		notes = new Vector<Note>();
	}
	public void add(Note note){
		notes.add(note);
	}
	public void add(int index,Note note){
		notes.add(index, note);
	}
	public Note get(int index){
		try{
			return notes.get(index);
		}catch(Exception e){
		}
		return null;
	}	
	public Iterator<Note> iterator(){
		return notes.iterator();
	}
	public void setNote(int index, int id){
		notes.get(index).change(id);
	}
	public void setNote(int index, Type type){
		notes.get(index).change(type);
	}
	public int size(){
		return notes.size();
	}
	public int indexOf(Note note) {
		Iterator<Note> it = notes.iterator();
		int index=0;
		while(it.hasNext()){
			if(note==it.next())
				break;
			index++;
		}
		return index;
	}
	public boolean removeNote(Note note) {
		return notes.remove(note);		
	}
	public boolean changeNote(Note destination, Note source) {
		int index = notes.indexOf(destination);
		if(index<0)
			return false;
		notes.remove(destination);
		notes.add(index,source);
		return true;
	}
}
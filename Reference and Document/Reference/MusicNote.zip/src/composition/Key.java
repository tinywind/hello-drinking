package composition;

import java.io.Serializable;

public class Key implements Serializable{
	/**
	 * ������ �ĵ��ַ���̽� ����
	 * ������ �ù̶󷹼ֵ��� ���� 
	 */
	private static final long serialVersionUID = 5051175157938208216L;

	private static final short[] MAJOR_C = {0,0,0,0,0,0,0};
	private static final short[] MAJOR_G = {0,0,0,1,0,0,0};
	private static final short[] MAJOR_D = {1,0,0,1,0,0,0};
	private static final short[] MAJOR_A = {1,0,0,1,1,0,0};
	private static final short[] MAJOR_E = {1,1,0,1,1,0,0};
	private static final short[] MAJOR_B = {1,1,0,1,1,1,0};
	private static final short[] MAJOR_F = {1,1,1,1,1,1,0};

	public static final Key major_c = new Key(MAJOR_C);
	public static final Key major_g = new Key(MAJOR_G);
	public static final Key major_d = new Key(MAJOR_D);
	public static final Key major_a = new Key(MAJOR_A);
	public static final Key major_e = new Key(MAJOR_E);
	public static final Key major_b = new Key(MAJOR_B);
	public static final Key major_f = new Key(MAJOR_F);

	private final short[] listShapOrFlap;

	private Key(short[] listShapOrFlap){
		this.listShapOrFlap = listShapOrFlap;
	}

	public short[] getListShapOrFlap() {
		return listShapOrFlap;
	}

	public String getKeyName(){
		if(getListShapOrFlap()[2]==1)
			return "Major F";
		if(getListShapOrFlap()[5]==1)
			return "Major B";
		if(getListShapOrFlap()[1]==1)
			return "Major E";
		if(getListShapOrFlap()[4]==1)
			return "Major A";
		if(getListShapOrFlap()[0]==1)
			return "Major D";
		if(getListShapOrFlap()[3]==1)
			return "Major G";

		return "Major C";
	}
}

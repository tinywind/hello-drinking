package composition;

import java.io.Serializable;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Point;

import com.jeon.musicnote.R;


public class Note implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -7287255254287673691L;
	private Type type;
	private int height; //-35~34 : ��� ����  0, pitch �δ� 60 :: 0 < pitch < 127
	//0 ���� �������� �Ʒ��� 5��Ÿ��. ���� 5��Ÿ�� ���
	public Note(int height){
		type = Type.WHOLE;		

		if(-35 <= height && height <= 34)
			this.height = height;
		else
			this.height = 0;
	}

	public Note(Type type){
		setMembers(type);
	}

	public Note(int height, int code) {
		setMembers(code);

		if(-35 <= height && height <= 34)
			this.height = height;
		else
			this.height = 0;
	}

	public Note(int height, Type type) {
		setMembers(type);

		if(-35 <= height && height <= 34)
			this.height = height;
		else
			this.height = 0;
	}

	private boolean setMembers(int code){
		Type temp = Type.findItemByCode(code);
		
		if(temp==null)
			return false;

		if(temp.getTypecode() > Type.MAX_TYPE.getTypecode())
			return false;
		
		type = temp;
		return true;
	}

	private void setMembers(Type type){
		this.type = type;	
	}

	public Bitmap getImage() {
		return NoteImageManager.getImageInfo(type).getImage();
	}

	public Bitmap getConvertedImage(){
		return NoteImageManager.getImageInfo(type).getConvertedImage();
	}
	
	public Point getImageCenterPoint(){
		return NoteImageManager.getImageInfo(type).getCenter();
	}

	public int getCode() {
		return type.getTypecode();
	}

	public boolean change(int code) {
		return setMembers(code);
	}

	public void change(Type type){
		setMembers(type);
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}	


	public static class Type implements Serializable{	
		/**
		 * 
		 */
		private static final long serialVersionUID = 2534680203740071498L;
		public static final Type WHOLE = new Type(1);
		public static final Type HALF = new Type(2);
		public static final Type QUARTHER = new Type(4);
		public static final Type EIGHTH = new Type(8);
		public static final Type SIXTEENTH = new Type(16);
		public static final Type THIRTYSECOND = new Type(32);
		public static final Type SIXTYFOURTH = new Type(64);	
		public static final Type MAX_TYPE = SIXTEENTH;

		private final int typecode;

		private Type(int typecode){
			this.typecode = typecode;
		}

		public int getTypecode(){
			return typecode;
		}

		public static Type findItemByCode(int code) {			
			switch(code){
			case 1:return WHOLE;
			case 2:return HALF;
			case 4:return QUARTHER;
			case 8:return EIGHTH;
			case 16:return SIXTEENTH;
			case 32:return THIRTYSECOND;
			case 64:return SIXTYFOURTH;
			}
			return null;
		}

		@Override
		public boolean equals(Object obj) {
			return (((Type)obj).getTypecode()==this.getTypecode());
		}
	}

	public static class NoteImageManager {
		private static NoteImageManager instance = new NoteImageManager();

		private static Resources res;

		private static NoteImageInfo whole;
		private static NoteImageInfo half;
		private static NoteImageInfo quarter;
		private static NoteImageInfo eighth;
		private static NoteImageInfo sixteenth;
		private static NoteImageInfo thirtysecond;
		private static NoteImageInfo sixtyfourth;

		private NoteImageManager(){}

		public static NoteImageManager getInstance(){
			return instance;
		}

		public static void init(Resources res) {
			NoteImageManager.res = res;
			whole = new NoteImageInfo(loadImage(R.drawable.note_1,Color.WHITE), new Point(7, 6));
			half = new NoteImageInfo(loadImage(R.drawable.note_2,Color.WHITE), new Point(5, 28));
			quarter = new NoteImageInfo(loadImage(R.drawable.note_4,Color.WHITE), new Point(5, 28));
			eighth = new NoteImageInfo(loadImage(R.drawable.note_8,Color.WHITE), new Point(5, 28));
			sixteenth = new NoteImageInfo(loadImage(R.drawable.note_16,Color.WHITE), new Point(5, 28));
			thirtysecond = new NoteImageInfo(loadImage(R.drawable.note_32,Color.WHITE), new Point(5, 33));
			sixtyfourth = new NoteImageInfo(loadImage(R.drawable.note_64,Color.WHITE), new Point(5, 40));
		}

		public static Bitmap rotate(Bitmap bitmap, int degrees) { 
			Bitmap converted = null;
			Matrix m = new Matrix(); 
			m.setRotate(degrees, (float) bitmap.getWidth()/2, (float) bitmap.getHeight()/2); 
			converted = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), m, true); 
			return converted; 
		}
		
		public static Bitmap loadImage(int id, int color) {
			try {
				Bitmap image = BitmapFactory.decodeResource(res, id);

				int sW = image.getWidth();
				int sH = image.getHeight();

				int[] pixels = new int[sW*sH];
				image.getPixels(pixels, 0, sW, 0, 0, sW, sH);
				for (int i =0;i < pixels.length; i++) {         
					if (pixels[i] == color)
						pixels[i] = Color.TRANSPARENT;
				}

				Bitmap image2  = Bitmap.createBitmap(pixels,0,sW,sW,sH,Bitmap.Config.ARGB_8888);

				return image2;
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
		}

		public static NoteImageInfo getImageInfo(Type type) {
			if (type.equals(Type.WHOLE))
				return whole;
			if (type.equals(Type.HALF))
				return half;
			if (type.equals(Type.QUARTHER))
				return quarter;
			if (type.equals(Type.EIGHTH))
				return eighth;
			if (type.equals(Type.SIXTEENTH))
				return sixteenth;
			if (type.equals(Type.THIRTYSECOND))
				return thirtysecond;

			return sixtyfourth;
		}

		public static class NoteImageInfo {
			private Bitmap image;
			private Bitmap convertedImage;
			private final Point center;

			NoteImageInfo(Bitmap image, Point center) {
				this.image = image;
				this.center = center;
				convertedImage = rotate(image,180);
			}

			public Bitmap getImage() {
				return image;
			}

			public Bitmap getConvertedImage(){
				return convertedImage;
			}
			
			public void setImage(Bitmap image) {
				this.image = image;
			}

			public Point getCenter() {
				return center;
			}
		}
	}
}
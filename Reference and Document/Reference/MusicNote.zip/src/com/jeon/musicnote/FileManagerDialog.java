package com.jeon.musicnote;

import android.app.Dialog;
import android.content.Context;

public class FileManagerDialog extends Dialog{

	public FileManagerDialog(Context context) {
		super(context);
	}

}

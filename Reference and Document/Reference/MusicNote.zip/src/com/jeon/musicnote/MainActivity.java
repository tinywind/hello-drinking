package com.jeon.musicnote;

import midi.MidiItem;
import midi.MidiPlayer;
import android.app.Activity;
import android.media.AudioManager;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;

import composition.Note.NoteImageManager;

import etc.MetaModel;
import etc.MidiModel;
import gui.MeasuresView;
import gui.MetaView;

public class MainActivity extends Activity{

	private static final int ID_NEW_MUSICNOTE = 1;
	private static final int ID_PLAY = 2;
	private static final int ID_STOP = 3;
	
	private MidiModel _midiModel;
	private MetaModel _metaModel;
	private MidiPlayer _player;
	
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        NoteImageManager.init(getResources());
        setContentView(R.layout.main);
        
        _midiModel = new MidiModel(new MidiItem());
        _metaModel = new MetaModel(_midiModel);
        
        MetaView metaView = (MetaView) findViewById(R.id.metaview);        
        metaView.setModel(_metaModel);
        
        MeasuresView measuresView = (MeasuresView) findViewById(R.id.measuresview);   
        measuresView.setModel(_midiModel);
        
		_player = new MidiPlayer(this,_midiModel.getMidiItem());
		
    }

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		menu.add(0, ID_NEW_MUSICNOTE, 1, "NEW MUSICNOTE");
		menu.add(0, ID_PLAY, 1, "PLAY");
		menu.add(0, ID_STOP, 1, "STOP");
		return super.onCreateOptionsMenu(menu);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch(item.getItemId()){
		case ID_NEW_MUSICNOTE:
			break;
		case ID_PLAY:
			_player.play();
			break;
		case ID_STOP:
			break;
		}
		
		return super.onOptionsItemSelected(item);
	}

	@Override
	protected void onDestroy() {
		_player.release();
		super.onDestroy();
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		AudioManager audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
		if(keyCode == KeyEvent.KEYCODE_VOLUME_UP){
			audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI);
			return true;
		}else if(keyCode == KeyEvent.KEYCODE_VOLUME_DOWN){
			audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI);
			return true;
		}else if(keyCode == KeyEvent.KEYCODE_BACK){
			return super.onKeyDown(keyCode, event);
		}
		return false;
	}
}
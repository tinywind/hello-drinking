package midi;


import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class MidiCreator {
	private static final byte[] ID_HEADER_CHUNK = {'M','T','h','d'};
	private static final byte[] ID_TRACK_CHUNK = {'M','T','r','k'};
	private static final byte[] META_EVENT_END_OF_TRACK = {0, (byte) 0xFF, 0x2F, 0};

	private static final byte[] HEADER_CHUNK_SIZE = {0,0,0,6};
	private static final byte DEFAULT_FORMATTYPE = 0;
	private static final byte DEFAULT_NUMBER_OF_TRACKS = 1;
	private static final byte DEFAULT_TIME_DIVISION_TYPE = 0;
	private static final byte DEFAULT_TIME_DIVISION = 16;

	private byte _formattype = DEFAULT_FORMATTYPE;
	private byte _numberOfTracks = DEFAULT_NUMBER_OF_TRACKS;
	private byte _time_division_type = DEFAULT_TIME_DIVISION_TYPE;
	private byte _time_division = DEFAULT_TIME_DIVISION;

	private List<Track> _tracks;

	public MidiCreator(){
		_tracks = new ArrayList<Track>();
	}

	public void removeAllTrack() {
		_tracks.clear();
	}
	public Track createTrack(){
		return (new Track());
	}
	
	public void setTimeDivision(byte clocksOfBit){
		_time_division = clocksOfBit;
	}
	
	public byte getTimeDivision(){
		return _time_division;
	}

	public void addTrack(Track track){
		_tracks.add(track);
	}

	public void writeToFile(String filepath) throws IOException{
		writeToFile(filepath, true);
	}

	public void writeToFile(String filepath, boolean isOverwriteMode) throws IOException{
		File file = new File(filepath);
		if(_tracks.size() == 0)
			throw new IOException("Track is empty!");
		
		FileOutputStream os = null;
		try{
			if (file.exists() && !isOverwriteMode)
				throw new IOException("File is already exists!");

			if (!file.exists())
				file.createNewFile();
			
			os = new FileOutputStream(file);
			writeHeader(os);
			writeTracks(os);
		}catch(IOException e){
			throw e;
		}finally{
			if(os != null)
				os.close();			
		}
	}

	private void writeHeader(FileOutputStream os) throws IOException {
		os.write(ID_HEADER_CHUNK);
		os.write(HEADER_CHUNK_SIZE);
		os.write(0);
		os.write(_formattype);
		os.write(0);
		os.write(_numberOfTracks);
		os.write(_time_division_type);
		os.write(_time_division);
	}

	private void writeTracks(FileOutputStream os) throws IOException {
		Iterator<Track> it = _tracks.iterator();
		while(it.hasNext()){
			os.write(ID_TRACK_CHUNK);

			byte[] events = it.next().getEvents();
			int size04 = events.length + META_EVENT_END_OF_TRACK.length;
			byte size01 = (byte) (size04 / (0xFF * 0xFF * 0xFF));
			size04 -= size01 * (0xFF * 0xFF * 0xFF);
			byte size02 = (byte) ((size04) / (0xFF * 0xFF));
			size04 -= size02 * (0xFF * 0xFF);
			byte size03 = (byte) ((size04) / (0xFF));
			size04 -= size03 * 0xFF;

			os.write(size01);
			os.write(size02);
			os.write(size03);
			os.write(size04);

			os.write(events);

			os.write(META_EVENT_END_OF_TRACK);
		}
	}

	class Track{
		//T.T can't find the method : rest node expression
		private List<Note> nodes;

		Track(){
			nodes = new ArrayList<Note>();
		}

		public void addNode(byte pitch, byte length){
			nodes.add(new Note(pitch, length));
		}

		public void addNode(byte pitch, byte amplitude, byte length){
			nodes.add(new Note(pitch, amplitude, length));
		}

		byte[] getEvents(){
			if(nodes.size()==0)
				return null;
			byte[] bytes = new byte[nodes.size()*3 + 1 + 4];

			Iterator<Note> it = nodes.iterator();

			Note node = it.next();
			int index = 0;
			bytes[index++] = 0;			
			bytes[index++] = (byte) 0x90;
			bytes[index++] = node.pitch;
			bytes[index++] = node.amplitude;

			while(it.hasNext()){
				bytes[index++] = node.length;
				node = it.next();
				bytes[index++] = node.pitch;
				bytes[index++] = node.amplitude;		
			}

			bytes[index++] = node.length;
			bytes[index++] = (byte) 0x80;
			bytes[index++] = 0;
			bytes[index++] = 0;

			return bytes;
		}

		class Note {
			byte pitch;
			byte amplitude;
			byte length;
			Note(byte pitch, byte length){
				this.pitch = pitch;
				this.amplitude = 60;
				this.length = length;
			}
			Note(byte pitch, byte amplitude, byte length){
				this.pitch = pitch;
				this.amplitude = amplitude;
				this.length = length;
			}
		}
	}
}

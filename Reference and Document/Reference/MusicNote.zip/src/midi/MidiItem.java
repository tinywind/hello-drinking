package midi;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import composition.Measure;
import composition.Note;

public class MidiItem implements Serializable{
	/**
	 *  12 : ��Ÿ���� ��� MetaInformation ���� ����
	 *  13 : ���� ���������� ǥ��
	 */
	private static final long serialVersionUID = 8463343415893525360L;
	private int version = 13; 
	
	private MetaInformation _metaInfo;
	private List<Measure> _measures;
	
	public MidiItem(){
		_measures = new Vector<Measure>();
		_metaInfo = new MetaInformation();
	}

	public short[] getListShapOrFlap(){
		return _metaInfo.getKey().getListShapOrFlap();
	}
	
	public MetaInformation getMetaInfo() {
		return _metaInfo;
	}

	public void setMetaInfo(MetaInformation metaInfo) {
		this._metaInfo = metaInfo;
	}

	public List<Measure> getMeasures(){
		return _measures;
	}
	
	public Measure getMeasure(int index){
		return _measures.get(index);
	}
	
	public void addMeasure(Measure measure){
		_measures.add(measure);
	}
	
	public boolean addNote(Measure dst, Note note){
		for(int i=0;i<_measures.size();i++){
			if(_measures.get(i)==dst){
				dst.add(note);
				return true;
			}
		}
		return false;
	}

	public boolean addNote(Measure dst, int index, Note note){
		for(int i=0;i<_measures.size();i++){
			if(_measures.get(i)==dst){
				dst.add(index, note);
				return true;
			}
		}
		return false;
	}
	
	public int changeMeasure(Measure destination, Measure source){
		int index = _measures.indexOf(destination);
		if(index<0)
			return index;
		_measures.remove(destination);
		_measures.add(index, source);		
		return index;	
	}

	public int removeMeasure(Measure destination) {
		int index = _measures.indexOf(destination);
		if(index<0)
			return index;
		_measures.remove(destination);	
		return index;	
	}	
	
	public boolean changeNote(Measure measure, Note destination, Note source){
		Iterator<Note> it = measure.iterator();			
		while(it.hasNext()){
			Note tempNote = it.next();
			if(tempNote==destination){
				return measure.changeNote(destination,source);
			}
		}
		return false;
	}
	public boolean changeNote(Note destination, Note source){
		Iterator<Measure> it = _measures.iterator();
		while(it.hasNext()){
			if(changeNote(it.next(),destination,source))
				return true;
		}
		return false;
	}
	
	public List<Note> getNotes() {
		List<Note> notes = new ArrayList<Note>();

		Iterator<Measure> it = _measures.iterator();
		while(it.hasNext()){
			Iterator<Note> it2 = it.next().iterator();
			while(it2.hasNext()){
				notes.add(it2.next());
			}
		}
		
		return notes;
	}
	public void read(File file){
		ObjectInputStream oi = null;

		try {
			oi = new ObjectInputStream(new FileInputStream(file));
			MidiItem item = (MidiItem) oi.readObject();
			if(item.version != this.version){
				//���� ���� ����ó��
				this.finalize();
			}else{
				this._measures = item._measures;
				this._metaInfo = item._metaInfo;
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (Throwable e) {
			e.printStackTrace();
		}finally{
			if(oi!=null){
				try {
					oi.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	public void read(String filepath){
		read(new File(filepath));
	}
	
	public void saveFile(String filepath){
		ObjectOutputStream oo = null;
		
		try {
			oo = new ObjectOutputStream(new FileOutputStream(new File(filepath)));
			oo.writeObject(this);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}finally{
			if(oo!=null){
				try {
					oo.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}		
	}
}

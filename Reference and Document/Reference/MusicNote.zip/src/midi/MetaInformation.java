package midi;

import java.io.Serializable;
import java.util.Date;

import composition.Key;

public class MetaInformation implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -8267352277193712151L;
	
	private static final int DEFALUT_TEMPO = 120;
	
	private Key key;
	private int tempo;
	
	private String author;
	private String title;
	private String copyright;
	private Date date;
	private String comment;
	
	public MetaInformation(){
		key=Key.major_c;
		tempo=DEFALUT_TEMPO;
		author="";
		title="";
		copyright="";
		date=new Date();
		comment="";
	}
	public MetaInformation(Key key, int tempo, String author, String title,
			String copyright, Date date, String comment) {
		super();
		this.key = key;
		this.tempo = tempo;
		this.author = author;
		this.title = title;
		this.copyright = copyright;
		this.date = date;
		this.comment = comment;
	}

	public Key getKey() {
		return key;
	}

	public void setKey(Key key) {
		this.key = key;
	}

	public int getTempo() {
		return tempo;
	}

	public void setTempo(int tempo) {
		this.tempo = tempo;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getCopyright() {
		return copyright;
	}

	public void setCopyright(String copyright) {
		this.copyright = copyright;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}
}
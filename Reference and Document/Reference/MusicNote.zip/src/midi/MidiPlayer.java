package midi;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import android.content.Context;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.SoundPool;
import android.os.Environment;
import android.util.Log;

import composition.Note;

public class MidiPlayer implements OnCompletionListener {
	private static final int DEFAULT_AMPLITUDE = 64;
	private static final short[] isSemiTone = {1, 1, 0, 1, 1, 1, 0};
	private static final String TEMP_FILENAME = "tempmidi";
	private static final String TEMP_FILENAME_EXPENSION = ".mid";

	private String temp_directory; 
	
	private MidiItem midi;
	private MidiCreator creator;
	private MediaPlayer player;
	private String tempFilePath;
	private Context context;
	
	public MidiPlayer(Context context, MidiItem midi){
		this.midi = midi;
		this.context = context;
		creator = new MidiCreator();
		player = new MediaPlayer();
		
		temp_directory = Environment.getExternalStorageDirectory().getAbsolutePath() + "/temp";
	}

	public void play(){			
		List<Note> notes = midi.getNotes();
		if(notes.size()==0)
			return;
		setTrack(notes);

		tempFilePath = temp_directory + "/" + TEMP_FILENAME + TEMP_FILENAME_EXPENSION;

		try {
			File dir = new File(temp_directory);
			if(!dir.exists())
				dir.mkdir();

			creator.writeToFile(tempFilePath);
			Log.i("FilePath",tempFilePath);
		} catch (Exception e) {
			Log.e("error",e.toString());
		}

		try {
			player = new MediaPlayer();		
			player.setOnCompletionListener(this);
			player.setDataSource(tempFilePath);	
			player.setAudioStreamType(AudioManager.STREAM_MUSIC);
			player.prepare();
			
			AudioManager mgr = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
			int streamVolume = mgr.getStreamVolume(AudioManager.STREAM_MUSIC);
			player.setVolume(streamVolume, streamVolume);
			player.start();
		} catch (Exception e) {
			Log.e("error","(2)"+e.toString());
		}	
	}

	public void release(){
		if(player != null){
			player.release();
		}
		File dir = new File(temp_directory);
		if(dir.exists()){
			String[] list = dir.list();
			for(int i=0;i<list.length;i++){
				File temp = new File(list[i]);
				temp.delete();
			}	
			dir.delete();
		}
	}

	public void writeToFile(String filepath){
		setTrack(midi.getNotes());

		try {
			creator.writeToFile(filepath);
		} catch (IOException e) {
			Log.e("error",e.toString());
		}		
	}

	private void setTrack(List<Note> notes){
		creator.removeAllTrack();
		MidiCreator.Track track = creator.createTrack();
		creator.addTrack(track);

		Iterator<Note> it = notes.iterator();

		while(it.hasNext()){
			Note note = it.next();

			track.addNode((byte)getPitch(note, note.getHeight()), 
					(byte)DEFAULT_AMPLITUDE, 
					(byte)((4.0/note.getCode())*creator.getTimeDivision()));
		}
	}

	private int getPitch(Note note, int height) {
		int rest = height%7;
		while(rest<0){
			if(rest<0)
				rest += 7;
		}
		int gap = 0;
		for(int i =0;i<rest;i++)
			gap += isSemiTone[i];

		gap += midi.getListShapOrFlap()[rest];

		return (height/7)*12+60+gap+rest;
	}

	@Override
	public void onCompletion(MediaPlayer mp) {
		mp.release();
		mp = null;
	}
}
